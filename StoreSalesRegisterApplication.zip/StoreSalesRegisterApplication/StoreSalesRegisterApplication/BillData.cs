﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreSalesRegisterApplication
{
    public class BillData
    {
        private int _id;
        private string _date;
        private string _time;
        private string _location;
        private ObservableCollection<FoodItemDetail> _foodItem;
        private double _numberOfItems;
        private double _numberOfUnits;
        private double _totalPrice;

        public int Id { get => _id; set => _id = value; }
        public string Date { get => _date; set => _date = value; }
        public string Time { get => _time; set => _time = value; }
        public string Location { get => _location; set => _location = value; }
        public ObservableCollection<FoodItemDetail> FoodItem { get => _foodItem; set => _foodItem = value; } 
        public double NumberOfItems { get => _numberOfItems; set => _numberOfItems = value; }
        public double NumberOfUnits { get => _numberOfUnits; set => _numberOfUnits = value; }
        public double TotalPrice { get => _totalPrice; set => _totalPrice = value; }
    }

    public class FoodItemDetail
    {
        private string _name;
        private double _price;
        private double _units;
        private double _itemPrice;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
        public double Units
        {
            get { return _units; }
            set { _units = value; }
        }
        public double ItemPrice
        {
            get { return Units*Price; }
            set { _itemPrice = value; }
        }
    }
}
