﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreSalesRegisterApplication
{
    class FileDataOperation
    {
        public string ReadDataFromJson(string filename)
        {
            return File.ReadAllText(filename);
        }

        public void WriteDataToJson(string filePath,string content)
        {
            File.WriteAllText(filePath, content);
        }
    }
}
