﻿using System.Windows.Controls;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.ComponentModel;

namespace StoreSalesRegisterApplication
{
    public class FoodItem
    {
        private string _id;
        private string _name;
        private double _price;
        private string _description;
        private string _imagePath;
        private double _units;
        private bool _isSelected;
        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
        public string Description
        {
            get { return Name+ "one unit price: "+Price; }
            set { _description = value; }
        }
        public string ImagePath
        {
            get { return _imagePath; }
            set { _imagePath = value; }
        }
        public double Units
        {
            get { return _units; }
            set { _units = value; }
        }
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; }
        }

        public FoodItem()
        {
            Units = 1;
            IsSelected = false;
        }
    }
}