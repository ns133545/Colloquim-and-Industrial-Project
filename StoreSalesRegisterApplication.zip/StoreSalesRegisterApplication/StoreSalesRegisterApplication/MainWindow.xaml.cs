﻿using C1.WPF;
using C1.WPF.DateTimeEditors;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using StoreSalesRegisterApplication.Pages;

namespace StoreSalesRegisterApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window 
    {
        public MainWindow()
        {
            InitializeComponent();
            NavigationSwitcher.pageSwitcher = this;
            new NavigationSwitcher().Switch(new OrderPage());
        }

        public void Navigate(UserControl newPage)
        {
            this.Content = newPage;
        }
    }
}