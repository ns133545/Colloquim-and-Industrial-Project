﻿using C1.WPF;
using Newtonsoft.Json;
using StoreSalesRegisterApplication.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StoreSalesRegisterApplication.Pages
{
    /// <summary>
    /// Interaction logic for OrderPage.xaml
    /// </summary>
    public partial class OrderPage : UserControl
    {

        DataViewModel dataVM;
        public OrderPage()
        {
            InitializeComponent();            
            dataVM = new DataViewModel();
            DataContext = dataVM;
            LoadData();
        }

        /// <summary>
        /// Load Controls
        /// </summary>
        private void LoadData()
        {
            navigationBar.OrderNavigation.Background = Brushes.White;
            locationComboBox.ItemsSource = dataVM.Location;
            filterItems.ItemsSource = dataVM.FoodItems;
            selectedItems.ItemsSource = dataVM.selectedFoodItemList;
        }
        /// <summary>
        /// Food Item Select
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FoodItemChecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkedBox = sender as CheckBox;
            FoodItem context = (FoodItem)checkedBox.DataContext;
            if (context != null)
            {
                dataVM.AddItem(context);
                BillUpdate();
            }
        }
        /// <summary>
        /// Food Item Unselect
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FoodItemUnchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkedBox = sender as CheckBox;
            FoodItem context = (FoodItem)checkedBox.DataContext;
            if (context != null)
            {
                dataVM.RemoveItem(context);
                BillUpdate();
            }
        }
        /// <summary>
        /// Unit updation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UnitChanged(object sender, PropertyChangedEventArgs<double> e)
        {
            C1NumericBox numericBox = sender as C1NumericBox;
            FoodItem context = (FoodItem)numericBox.DataContext;
            if (context != null)
            {
                BillUpdate();
            }
        }
        private void BillUpdate()
        {
            selectedItemUnits.Content = dataVM.NumberOfUnits.ToString();
            selectedItemPrice.Content = dataVM.TotalPrice.ToString();
        }
        /// <summary>
        /// Submit Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BillSubmit(object sender, RoutedEventArgs e)
        {
            BillData bill = new BillData();
            Location location = locationComboBox.SelectedItem as Location;            
            ObservableCollection<BillData> billData = new ObservableCollection<BillData>();
            if(File.Exists(Properties.Resources.BillDataFile))
                billData = JsonConvert.DeserializeObject<ObservableCollection<BillData>>(new FileDataOperation().ReadDataFromJson(Properties.Resources.BillDataFile));
            foreach(var item in dataVM.selectedFoodItemList)
            {
                FoodItemDetail foodItem = new FoodItemDetail();
                foodItem.Name = item.Name;
                foodItem.Units = item.Units;
                foodItem.Price = item.Price;
                dataVM.SelectedFoodItemDetails.Add(foodItem);
            }
            bill.Id = billData.Count+1;
            bill.Date = userDate.Text;
            bill.Time = userTime.Value.ToString();
            bill.Location = location.Name;
            bill.FoodItem = dataVM.SelectedFoodItemDetails;
            bill.NumberOfItems = Convert.ToDouble(selectedItemNumbers.Content.ToString());
            bill.NumberOfUnits = Convert.ToDouble(selectedItemUnits.Content.ToString());
            bill.TotalPrice = Convert.ToDouble(selectedItemPrice.Content.ToString());
            if (bill.NumberOfItems > 0)
            {
                billData.Add(bill);
                string filePath = Properties.Resources.BillDataFile;
                string fileContent = JsonConvert.SerializeObject(billData);
                new FileDataOperation().WriteDataToJson(filePath, fileContent);
                lblStatus.Content = Properties.Resources.SuccessMessage;
                lblStatus.Foreground = Brushes.Green;
            }
            else
            {
                lblStatus.Content = Properties.Resources.LessItemSelection;
                lblStatus.Foreground = Brushes.Red;
            }
        }

        private void HourIncreament(object sender, RoutedEventArgs e)
        {
            userTime.Value += new TimeSpan(1, 0, 0);
        }

        private void HourDecreament(object sender, RoutedEventArgs e)
        {
            userTime.Value -= new TimeSpan(1, 0, 0);
        }

        private void MinuteIncreament(object sender, RoutedEventArgs e)
        {
            userTime.Value += new TimeSpan(0, 1, 0);
        }

        private void MinuteDecreament(object sender, RoutedEventArgs e)
        {
            userTime.Value -= new TimeSpan(0, 1, 0);
        }

        private void AmPmClick(object sender, RoutedEventArgs e)
        {
            if(userTime.Value<=new TimeSpan(12,0,0))
                userTime.Value += new TimeSpan(12, 0, 0);
            else
                userTime.Value -= new TimeSpan(12, 0, 0);

        }
    }
}
