﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C1.WPF.FlexGrid;
using StoreSalesRegisterApplication.ViewModel;

namespace StoreSalesRegisterApplication.Pages
{
    /// <summary>
    /// Interaction logic for ReportsPage.xaml
    /// </summary>
    public partial class ReportsPage : UserControl
    {
        DataViewModel dataVM;
        List<string> headerName;
        List<BillData> listView;
        List<BillData> listData;
        int currentPage, recPerPage,totalPage;
        public static string searchData;
        public ReportsPage()
        {
            InitializeComponent();
            dataVM = new DataViewModel();
            headerName = new List<string>();
            navigationBar.ReportsNavigation.Background = Brushes.White;
            listData = new List<BillData>();
            listView = new List<BillData>();
            listData = dataVM.BillOrder.ToList();
            LoadReports();
        }
        /// <summary>
        /// Reports Tab Load
        /// </summary>
        private void LoadReports()
        {
            if (new DataViewModel().BillOrder.Count < 1)
                MessageBox.Show(Properties.Resources.EmptyGridMessage, Properties.Resources.EmptyGridCaption, MessageBoxButton.OK, MessageBoxImage.Warning);
            RefreshGrid(new object(), new RoutedEventArgs());
            salesGrid.CellFactory = new GridCellStyle();
            new C1FlexGridFilter(salesGrid);
            
            foreach (var column in salesGrid.Columns)
                headerName.Add(column.Header);            
            columnFilter.comboHeaders.ItemsSource = headerName;
            salesGrid.ColumnHeaders.MouseUp += ColumnHeaderClick;
        }
        /// <summary>
        /// column filter updation event for column data load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColumnFilterUpdated(object sender, RoutedEventArgs e)
        {
            int column = 0;
            foreach (var col in salesGrid.Columns)
            {
                if (col.Header == columnFilter.comboHeaders.SelectedItem.ToString())
                {
                    column = col.Index;
                    break;
                }
            }
            List<string> itemList = new List<string>();
            salesGrid.ItemsSource = dataVM.BillOrder;
            foreach (var row in salesGrid.Rows)
            {
                if (salesGrid.Cells[row.Index, column] != null)
                    itemList.Add(salesGrid.Cells[row.Index, column].ToString());
                itemList = itemList.Distinct().ToList();
            }
            salesGrid.ItemsSource = listView;
            GroupRowDiffer();
            columnFilter.comboItems.ItemsSource = itemList;
            columnFilter.comboItems.SelectedIndex = 0;
        }
        /// <summary>
        /// column filter event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemFilter(object sender, RoutedEventArgs e)
        {
            bool found = false;
            int column = 0;
            foreach (var col in salesGrid.Columns)
            {
                if (col.Header == columnFilter.comboHeaders.SelectedItem.ToString())
                {
                    column = col.Index;
                    break;
                }
            }
            salesGrid.ItemsSource = dataVM.BillOrder;
            //for parent items
            if (salesGrid.Cells[0, column] != null)
            {
                foreach (var row in salesGrid.Rows)
                {
                    if (salesGrid.Cells[row.Index, column] != null && salesGrid.Cells[row.Index, column].ToString().ToLower() != columnFilter.comboItems.Text.ToLower())
                    {
                        found = true;
                        ((GroupRow)row).Visible = false;
                        continue;
                    }
                    if (((GroupRow)row).HasChildren == true)
                        found = false;
                    if (found == true)
                        ((GroupRow)row).Visible = false;
                }
            }
            //for child items
            else
            {
                for (int rowindex = salesGrid.Rows.Count - 1; rowindex >= 0; rowindex--)
                {
                    if (salesGrid.Cells[rowindex, column] != null && salesGrid.Cells[rowindex, column].ToString().ToLower() != columnFilter.comboItems.Text.ToLower())
                    {
                        ((GroupRow)salesGrid.Rows[rowindex]).Visible = false;
                        continue;
                    }
                    if (((GroupRow)salesGrid.Rows[rowindex]).HasChildren == false)
                        found = true;
                    else
                    {
                        if (found == true)
                            found = false;
                        else
                            ((GroupRow)salesGrid.Rows[rowindex]).Visible = false;
                    }
                }
                //for remaining child items
                bool parentFound = false;
                foreach (var row in salesGrid.Rows)
                {
                    if (((GroupRow)row).HasChildren)
                    {
                        if (((GroupRow)row).IsVisible)
                            parentFound = true;
                        else
                            parentFound = false;
                        continue;
                    }
                    if (parentFound == true)
                        ((GroupRow)row).Visible = true;
                }
            }
            listData.Clear();
            foreach (var row in salesGrid.Rows)
            {
                if (((GroupRow)row).HasChildren && ((GroupRow)row).IsVisible)
                {
                    listData.Add((BillData)((GroupRow)row).DataItem);
                }
            }
            FirstPageEvent(new object(), new RoutedEventArgs());
        }
        /// <summary>
        /// Color differentiator for Group Rows
        /// </summary>
        private void GroupRowDiffer()
        {
            bool groupType = true;
            foreach (var row in salesGrid.Rows)
            {
                ((GroupRow)row).IsCollapsed = true;
                if (row.IsVisible == true)
                    groupType = (!groupType);
                row.Background = groupType ? Brushes.White : Brushes.LightGray;
            }
            foreach (var row in salesGrid.Rows)
                ((GroupRow)row).IsCollapsed = false;
        }        
        /// <summary>
        /// Event for column header click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColumnHeaderClick(object sender, MouseButtonEventArgs e)
        {
            salesGrid.ItemsSource = listData;
            GroupRowDiffer();
        }

        /// <summary>
        /// Column Sort Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColumnsSorted(object sender, CellRangeEventArgs e)
        {
            listData.Clear();
            foreach(var row in salesGrid.Rows)
            {
                if (((GroupRow)row).HasChildren && ((GroupRow)row).IsVisible)
                {
                    listData.Add((BillData)((GroupRow)row).DataItem);
                }
            }
            FirstPageEvent(new object(), new RoutedEventArgs());
            GroupRowDiffer();
            ExpandAll(this,new RoutedEventArgs());           
        }
        /// <summary>
        /// Default column filter 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColumnFilterApplied(object sender, EventArgs e)
        {
            GroupRowDiffer();
            ExpandAll(new object(), new RoutedEventArgs());
        }
        /// <summary>
        /// Collapse Grid Rows
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CollapseAll(object sender, RoutedEventArgs e)
        {
            groupRowVisibility.Content = Properties.Resources.GroupRowExpand;
            groupRowVisibility.IsChecked = true;
            foreach (var row in salesGrid.Rows)
                if (((GroupRow)row).IsVisible)
                    ((GroupRow)row).IsCollapsed = true;
        }
        /// <summary>
        /// Expand Grid Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExpandAll(object sender, RoutedEventArgs e)
        {
            groupRowVisibility.Content = Properties.Resources.GroupRowCollapse;
            groupRowVisibility.IsChecked = false;
            foreach (var row in salesGrid.Rows)
                if(((GroupRow)row).IsVisible)
                    ((GroupRow)row).IsCollapsed = false;
        }
        /// <summary>
        /// Sort grid by Id(Descending)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortGridDescending(object sender, RoutedEventArgs e)
        {
            sortById.Content = Properties.Resources.SortAscending;
            sortById.IsChecked = true;
            listData = listData.OrderByDescending(o => o.Id).ToList();
            FirstPageEvent(new object(), new RoutedEventArgs());
        }
        /// <summary>
        /// Sort grid by Id(Ascending)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortGridAscending(object sender, RoutedEventArgs e)
        {
            sortById.Content = Properties.Resources.SortDescending;
            sortById.IsChecked = false;
            listData = listData.OrderBy(o => o.Id).ToList();
            FirstPageEvent(new object(), new RoutedEventArgs());
        }
        /// <summary>
        /// Refresh grid to the overall data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RefreshGrid(object sender, RoutedEventArgs e)
        {
            currentPage = 1;
            recPerPage = Convert.ToInt32(flexPaginator.comboRecPerPage.Text);
            listData = dataVM.BillOrder.ToList();
            totalPage = (listData.Count) / recPerPage;
            if ((listData.Count) % recPerPage != 0)
                totalPage++;
            listView = listData.Take(recPerPage).ToList();
            salesGrid.ItemsSource = listView;
            flexPaginator.lblCurrentPage.Content = currentPage;
            flexPaginator.lblTotalPage.Content = totalPage;
            flexPaginator.btnFirstPage.IsEnabled = false;
            flexPaginator.btnPreviousPage.IsEnabled = false;
            flexPaginator.btnLastPage.IsEnabled = true;
            flexPaginator.btnNextPage.IsEnabled = true;
            GroupRowDiffer();
        }
        /// <summary>
        /// Date Range Filter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DateFilter(object sender, RoutedEventArgs e)
        {
            DateTime startDate = DateTime.Parse(gridDateRange.startDateFilter.Text);
            DateTime endDate = DateTime.Parse(gridDateRange.endDateFilter.Text);
            listData.Clear();
            foreach (var item in dataVM.BillOrder)
            {
                DateTime compareDate = DateTime.Parse(item.Date);
                if (compareDate > startDate && compareDate < endDate)
                    listData.Add(item);
                if (compareDate == startDate || compareDate == endDate)
                    listData.Add(item);
            }
            FirstPageEvent(new object(), new RoutedEventArgs());
            if(listData.Count==0)
                MessageBox.Show(Properties.Resources.EmptyGridMessage, Properties.Resources.EmptyGridCaption, MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        /// <summary>
        /// column resize for trimming
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColumnResize(object sender, CellRangeEventArgs e)
        {
            salesGrid.Columns[e.Column].TextTrimming = TextTrimming.CharacterEllipsis;
            salesGrid.Columns[e.Column].HeaderTextTrimming = TextTrimming.CharacterEllipsis;
        }
        /// <summary>
        /// navigate to first page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FirstPageEvent(object sender, RoutedEventArgs e)
        {
            currentPage = 1;
            recPerPage = Convert.ToInt32(flexPaginator.comboRecPerPage.Text);
            totalPage = (listData.Count) / recPerPage;
            if ((listData.Count) % recPerPage != 0)
                totalPage++;
            listView = listData.Take(recPerPage).ToList();
            salesGrid.ItemsSource = listView;
            flexPaginator.lblCurrentPage.Content = currentPage;
            flexPaginator.lblTotalPage.Content = totalPage;
            flexPaginator.btnFirstPage.IsEnabled = false;
            flexPaginator.btnPreviousPage.IsEnabled = false;
            flexPaginator.btnLastPage.IsEnabled = totalPage>1?true:false;
            flexPaginator.btnNextPage.IsEnabled = totalPage > 1 ? true : false;
            GroupRowDiffer();
        }
        /// <summary>
        /// Navigate to last page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LastPageEvent(object sender, RoutedEventArgs e)
        {
            currentPage = totalPage;
            listView = listData.Skip((currentPage-1) * recPerPage).Take(recPerPage).ToList();
            salesGrid.ItemsSource = listView;
            flexPaginator.lblCurrentPage.Content = currentPage;
            flexPaginator.btnFirstPage.IsEnabled = totalPage > 1 ? true : false;
            flexPaginator.btnPreviousPage.IsEnabled = totalPage > 1 ? true : false;
            flexPaginator.btnLastPage.IsEnabled = false;
            flexPaginator.btnNextPage.IsEnabled = false;
            GroupRowDiffer();
        }       

        /// <summary>
        /// Navigate to next page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextPageEvent(object sender, RoutedEventArgs e)
        {
            if(currentPage<totalPage)
            {
                listView = listData.Skip(currentPage * recPerPage).Take(recPerPage).ToList();
                salesGrid.ItemsSource = listView;
                GroupRowDiffer();
                currentPage++;
                flexPaginator.lblCurrentPage.Content = currentPage;
                flexPaginator.btnFirstPage.IsEnabled = true;
                flexPaginator.btnPreviousPage.IsEnabled = true;
            }      
            if(currentPage == totalPage)
            {
                flexPaginator.btnLastPage.IsEnabled = false;
                flexPaginator.btnNextPage.IsEnabled = false;
            }
        }       

        /// <summary>
        /// Navigate to previous page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PreviousPageEvent(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                listView = listData.Skip((currentPage-2) * recPerPage).Take(recPerPage).ToList();
                salesGrid.ItemsSource = listView;
                GroupRowDiffer();
                currentPage--;
                flexPaginator.lblCurrentPage.Content = currentPage;
                flexPaginator.btnLastPage.IsEnabled = true;
                flexPaginator.btnNextPage.IsEnabled = true;
            }
            if (currentPage == 1)
            {
                flexPaginator.btnFirstPage.IsEnabled = false;
                flexPaginator.btnPreviousPage.IsEnabled = false;
            }
        }
        /// <summary>
        /// Record per Page updated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RecordPerPageEvent(object sender, RoutedEventArgs e)
        {

            flexPaginator.comboRecPerPage.Text = flexPaginator.comboRecPerPage.SelectedItem.ToString();
            FirstPageEvent(this, new RoutedEventArgs());
        }
        /// <summary>
        /// Copy selected data from grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CopySelectedData(object sender, RoutedEventArgs e)
        {
            salesGrid.Copy();
            MessageBox.Show(Properties.Resources.Copy);
        }
        /// <summary>
        /// Copy all Bill data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CopyAllData(object sender, RoutedEventArgs e)
        {
            salesGrid.ItemsSource = dataVM.BillOrder;
            salesGrid.SelectAll();
            salesGrid.Copy();
            FirstPageEvent(new object(), new RoutedEventArgs());
            salesGrid.Select(0, 0);
            MessageBox.Show(Properties.Resources.Copy);
        }

        private void searchTextChange(object sender, TextChangedEventArgs e)
        {
            salesGrid.ItemsSource = listData;
            if (((TextBox)sender).Text==string.Empty)
                FirstPageEvent(new object(), new RoutedEventArgs());
            searchData = ((TextBox)sender).Text;
        }

        /// <summary>
        /// Print Preview of grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PrintPreviewGrid(object sender, RoutedEventArgs e)
        {
            salesGrid.ItemsSource = listData;
            GroupRowDiffer();
            salesGrid.PrintPreview(string.Empty, ScaleMode.ActualSize, new Thickness(0), 100);            
            FirstPageEvent(new object(), new RoutedEventArgs());
        }
        /// <summary>
        /// Print contents of Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PrintGrid(object sender, RoutedEventArgs e)
        {
            salesGrid.ItemsSource = listData;
            GroupRowDiffer();
            PrintParameters printParameters = new PrintParameters();
            printParameters.Margin = new Thickness(20, 50, 20, 50);
            printParameters.ScaleMode = ScaleMode.ActualSize;
            salesGrid.Print(printParameters);
            FirstPageEvent(new object(), new RoutedEventArgs());
        }
    }

    /// <summary>
    /// class for highlighting cell style
    /// </summary>
    public class GridCellStyle : CellFactory
    {
        public override void ApplyCellStyles(C1FlexGrid grid, CellType cellType, CellRange range, Border border)
        {
            var columnIndex = range.Column;
            var rowIndex = range.Row;
            int column = 0;
            foreach (var col in grid.Columns)
            {
                if (col.Header == Properties.Resources.TimeFilterColumn)
                {
                    column = col.Index;
                    break;
                }
            }
            if(cellType==CellType.Cell)
            {
                //group row style
                if (((GroupRow)grid.Rows[rowIndex]).HasChildren)
                {
                    border.BorderBrush = Brushes.Black;
                    border.BorderThickness = new Thickness(0, 1, 0, 0);
                }
                //time exceed cell style
                if (grid[rowIndex, columnIndex] != null)
                {
                    if ((columnIndex == column) && (DateTime.Parse(grid.Cells[rowIndex, columnIndex].ToString()) >= DateTime.Parse(new TimeSpan(21, 0, 0).ToString())))
                    {
                        border.BorderBrush = Brushes.Red;
                        border.BorderThickness = new Thickness(3);
                        border.CornerRadius = new CornerRadius(3);
                    }
                    if (ReportsPage.searchData!=null && grid.Cells[rowIndex, columnIndex].ToString().ToLower().Contains(ReportsPage.searchData.ToLower()))
                    {
                        border.Background = Brushes.Yellow;
                    }
                }                 
            }                           
        }
    }
}
