﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace StoreSalesRegisterApplication
{
    class SelectedFoodItemDetail
    {
        private string _description;
        private double _numberOfItems;
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public double NumberOfItems
        {
            get { return _numberOfItems;}
            set { _numberOfItems = value;
            }
        }
    }
}
