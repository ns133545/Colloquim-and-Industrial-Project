﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StoreSalesRegisterApplication.UserControls
{
    /// <summary>
    /// Interaction logic for FlexPagination.xaml
    /// </summary>
    public partial class FlexPagination : UserControl
    {
        public FlexPagination()
        {
            InitializeComponent();
            List<int> record = new List<int>();
            for (int index = 1; index <= 5; index++)
                record.Add(index * 5);
            comboRecPerPage.ItemsSource = record;
        }
        public event RoutedEventHandler FirstPageClick;
        public event RoutedEventHandler PreviousPageClick;
        public event RoutedEventHandler NextPageClick;
        public event RoutedEventHandler LastPageClick;
        public event RoutedEventHandler RecordPerPageChanged;
        
        private void FirstPage(object sender, RoutedEventArgs e)
        {
            if (FirstPageClick != null)
                FirstPageClick(this, new RoutedEventArgs());
        }

        private void PreviousPage(object sender, RoutedEventArgs e)
        {
            if (PreviousPageClick != null)
                PreviousPageClick(this, new RoutedEventArgs());
        }

        private void NextPage(object sender, RoutedEventArgs e)
        {
            if (NextPageClick != null)
                NextPageClick(this, new RoutedEventArgs());
        }

        private void LastPage(object sender, RoutedEventArgs e)
        {
            if (LastPageClick != null)
                LastPageClick(this, new RoutedEventArgs());
        }
        
        private void RecordPerPage(object sender, SelectionChangedEventArgs e)
        {
            if(RecordPerPageChanged!=null)
                RecordPerPageChanged(this,new RoutedEventArgs());
        }
    }
}
