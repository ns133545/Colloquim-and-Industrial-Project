﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StoreSalesRegisterApplication.UserControls
{
    /// <summary>
    /// Interaction logic for TimeMinute.xaml
    /// </summary>
    public partial class TimeMinute : UserControl
    {
        public TimeMinute()
        {
            InitializeComponent();
        }
        public event RoutedEventHandler IncreamentClick;
        public event RoutedEventHandler DecreamentClick;
        public event RoutedEventHandler AmPmEventClick;
        private void MinuteIncreament(object sender, RoutedEventArgs e)
        {
            if (IncreamentClick != null)
                IncreamentClick(this, new RoutedEventArgs());
        }

        private void AmPmClick(object sender, RoutedEventArgs e)
        {
            if (AmPmEventClick != null)
                AmPmEventClick(this, new RoutedEventArgs());
        }

        private void MinuteDecreament(object sender, RoutedEventArgs e)
        {
            if (DecreamentClick != null)
                DecreamentClick(this, new RoutedEventArgs());
        }
    }
}
