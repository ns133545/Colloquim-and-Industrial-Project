﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoreSalesRegisterApplication.ViewModel
{
    public class DataViewModel :INotifyPropertyChanged
    {
        public ObservableCollection<Location> location;
        public ObservableCollection<FoodItem> foodItems;
        public ObservableCollection<FoodItem> selectedFoodItemList = new ObservableCollection<FoodItem>();
        public ObservableCollection<FoodItemDetail> selectedFoodItemDetails = new ObservableCollection<FoodItemDetail>();
        public ObservableCollection<BillData> billOrder;
        public event PropertyChangedEventHandler PropertyChanged;
        private double _numberOfItems=1;
        private double _numberOfUnits=0;
        private double _totalPrice=0;
        private bool _isSelected;
        public DataViewModel()
        {
            string locationData = new FileDataOperation().ReadDataFromJson(Properties.Resources.LocationFile);
            string foodItemdata = new FileDataOperation().ReadDataFromJson(Properties.Resources.FoodItemFile);
            string billOrderData = new FileDataOperation().ReadDataFromJson(Properties.Resources.BillDataFile);
            location = JsonConvert.DeserializeObject<ObservableCollection<Location>>(locationData);
            foodItems = JsonConvert.DeserializeObject<ObservableCollection<FoodItem>>(foodItemdata);
            billOrder = JsonConvert.DeserializeObject<ObservableCollection<BillData>>(billOrderData);
        }
        public ObservableCollection<Location> Location
        {
            get { return location; }
        }
        public ObservableCollection<FoodItem> FoodItems
        {
            get { return foodItems; }
            set { foodItems = value; }
        }
        public ObservableCollection<FoodItem> SelectedFoodItemList
        {
            get { return selectedFoodItemList; }
            set { selectedFoodItemList = value; }
        }
        public ObservableCollection<FoodItemDetail> SelectedFoodItemDetails
        {
            get { return selectedFoodItemDetails; }
            set { selectedFoodItemDetails = value; }
        }
        public ObservableCollection<BillData> BillOrder
        {
            get { return billOrder; }
        }
        public void AddItem(FoodItem item)
        {
            selectedFoodItemList.Add(item);
        }
        public void RemoveItem(FoodItem item)
        {
            selectedFoodItemList.Remove(item);
        }        

        public double NumberOfItems
        {
            get {
                if (IsSelected == true)
                    _numberOfItems++;
                else
                    _numberOfItems--;
                return _numberOfItems; }
            set
            {
                _numberOfItems = value;
                OnPropertyChanged(nameof(NumberOfUnits));
            }
        }
        public double NumberOfUnits
        {
            get
            {
                _numberOfUnits = 0;
                foreach(var item in SelectedFoodItemList)
                    _numberOfUnits += item.Units;
                return _numberOfUnits;
            }
            set
            {
                _numberOfUnits=value;
                OnPropertyChanged(nameof(NumberOfItems));
            }
        }
        public double TotalPrice
        {
            get
            {
                _totalPrice = 0;
                foreach (var item in SelectedFoodItemList)
                    _totalPrice += item.Units * item.Price;
                return _totalPrice;
            }
            set
            {
                _totalPrice = value;
                OnPropertyChanged(nameof(TotalPrice));
            }
        }

        public bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                _isSelected = value;
                OnPropertyChanged(nameof(NumberOfItems));
            }
        }


        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
